CUDA_VISIBLE_DEVICES=0,1 python web.py \
    --model 'JessyTsu1/ChatLaw-13B'